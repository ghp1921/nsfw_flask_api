import json
import time
import random
import requests


# access_token加密
now_time = str(int(time.time()))
a = int(random.random()*10)
b = now_time[5:]
s = int(a) * int(b)
access_token = str(s)[::-1]
# print(access_token)
# 图片准备
file = {
    'image':open('local files/img.png', 'rb')
}
url = 'http://127.0.0.1:5000/?access_token={}'.format(access_token)
re = requests.post(url=url,files=file)
content = json.loads(re.text)
print(dict(content))
