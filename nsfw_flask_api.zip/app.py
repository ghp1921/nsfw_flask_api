import base64
import json
import time
import warnings

warnings.filterwarnings("ignore")
from nsfw_detector import predict
from flask import Flask, request

app = Flask(__name__)


@app.route('/', methods=["GET", "POST"])
def model_classify_api():  # put application's code here
    # 接收access_token(get)
    access = request.args['access_token']

    # 判断access_token
    # base64解密
    try:
        shang = int(access[::-1]) // int(str(int(time.time()))[5:])
        if not shang <= 10:
            return 'access denied'
    except:
        return 'access denied'

    # 构建产品id
    id = str(int(time.time())) + '0001'
    # 接收图片
    # print('开始接收图片', id)
    image_content = request.files['image']
    if image_content is None:
        # print('未上传文件！')
        result = '未上传文件！'
    else:
        image_content.save('nsfw_detector/data/test.png')
        # print('上传文件成功！')
        start_2 = time.time()
        # 初始化模型
        try:
            time.sleep(0.5)
            model = predict.load_model('nsfw_detector/nsfw.299x299.h5')
            result = predict.classify(model, r'nsfw_detector\data\test.png')
        except:
            return '400'
        # print(result)
        result = {
            'cost_time': str(time.time() - start_2) + 's',
            'ends': result
        }

    # 封装data
    data = {'access_token': access, 'id': id, 'result': result}
    response = json.dumps(data)
    return response, 200, {"Content-Type": "application/json;charset=UTF-8"}


if __name__ == '__main__':
    app.run(debug=True)
